import React from 'react';

import Header from '../../components/header/header.component';

//base off of exercise15c from ClientSide & shop page from reactproject
const HomePage = () => (
  <div>
    <Header />
    <main>
      <p>This is a test for now!</p>
    </main>
  </div>
);

export default HomePage;

