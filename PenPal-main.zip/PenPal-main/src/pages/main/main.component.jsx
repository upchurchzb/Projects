import React from 'react';

import './main.styles.css';

const Main = () => (
  <div></div>
);

export default Main;