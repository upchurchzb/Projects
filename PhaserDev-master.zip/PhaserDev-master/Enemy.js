class Dino {
    
    constructor(x, y, scene){
        
    }
}
