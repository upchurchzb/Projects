class MainRoom1 extends Phaser.Scene {
    constructor() {
        super("MainRoom1");
    }

    preload() {
        this.load.spritesheet('player', 'assets/adventurerSheet.png', {frameWidth: 50, frameHeight: 38});
        this.load.image('floor', 'assets/assets/floor.png');
        this.load.spritesheet('door', 'assets/Door_Open_v2.png', {frameWidth: 18, frameHeight: 32});
        this.load.image('key', 'assets/key.png');
        this.load.image('ladder', 'assets/ladder2.png');
    }

    create() {
        gameState.active = true;
        this.createPlayer();
        this.createRoom();
        this.createAnimations();
        this.setColliders();
        this.roomLabel = this.add.text(425, 6, "Main Room", {
            font: "10px arial",
            color: "#000000",
            align: 'left'
        });
        this.helpText = this.add.text(6, 6, "Move: Arrow Keys\nJump: Up Arrow/Space", {
            font: "12px arial",
            color: "#000000",
            align: 'left',
        });
        this.objText = this.add.text(300, 40, "Collect the key to open the door", {
            font: "24px arial",
            color: "#000000",
            align: 'center',
            fontWeight: 'bold'
        });
    }

    update() {
        if (gameState.active) {
            if (gameState.cursors.left.isDown) {
                gameState.player.setVelocityX(-gameState.speed);
                gameState.player.anims.play('run', true);
                gameState.player.flipX = true;
            }
            else if (gameState.cursors.right.isDown) {
                gameState.player.setVelocityX(gameState.speed);
                gameState.player.anims.play('run', true);
                gameState.player.flipX = false;
            }
            else {
                gameState.player.setVelocityX(0);
                gameState.player.anims.play('idle', true);
            }

            if ((gameState.cursors.space.isDown || gameState.cursors.up.isDown)
                && gameState.player.body.touching.down) {
                gameState.player.setVelocity(-400);
                gameState.player.anims.play('jump', true);
            }

            this.physics.add.overlap(gameState.player, gameState.ladder, function() {
                if (gameState.cursors.up.isDown) {
                    gameState.player.setVelocityY(-125);
                    gameState.player.anims.play('climb', true);
                }
            });

            this.physics.add.overlap(gameState.player, gameState.door, function() {
                if (gameState.doorOpen) {
                    this.cameras.main.fade(800, 0, 0, 0, false, function(camera, progress) {
                        this.scene.stop("main");
                        this.scene.start("Tripp2");
                    });
                }
            }, null, this);
        }
    }

    createPlayer() {
        gameState.player = this.physics.add.sprite(50, 500, 'player').setScale(1.5);
        gameState.player.body.setSize(10, 35, true);
        gameState.cursors = this.input.keyboard.createCursorKeys();
    }

    createRoom() {
        gameState.floor = this.physics.add.staticGroup();
        gameState.floor.create(500, 575, 'floor');

        gameState.ladder = this.physics.add.sprite(150, 465, 'ladder').setDepth(-10);

        gameState.platforms = this.physics.add.staticGroup();
        gameState.platforms.create(245, 410, 'floor').setScale(0.15, 0.35).refreshBody();
        gameState.platforms.create(525, 320, 'floor').setScale(0.15, 0.35).refreshBody();

        gameState.key = this.physics.add.image(525, 225, 'key').setScale(.5).setImmovable(true);
        gameState.key.body.setAllowGravity(false);
        
        gameState.door = this.physics.add.sprite(850, 501, 'door').setScale(1.5).setDepth(-25);
        gameState.doorOpen = false;
    }
    
    createAnimations() {
        this.anims.create({
            key: 'run',
            frames: this.anims.generateFrameNumbers('player', {start: 8, end: 13}),
            frameRate: 5,
            repeat: -1
        });
        this.anims.create({
            key: 'idle',
            frames: this.anims.generateFrameNumbers('player', {start: 0, end: 3}),
            frameRate: 5,
            repeat: -1
        });
        this.anims.create({
            key: 'jump',
            frames: this.anims.generateFrameNumbers('player', {start: 13, end: 16}),
            frameRate: 5,
            repeat: -1
        });
        this.anims.create({
            key: 'climb',
            frames: this.anims.generateFrameNumbers('player', {start: 81, end: 84}),
            frameRate: 5,
            repeat: -1
        });
        this.anims.create({
            key: 'open',
            frames: this.anims.generateFrameNumbers('door', {start: 0, end: 4}),
            frameRate: 5,
            repeat: 0
        });
    }

    setColliders() {
        gameState.player.setCollideWorldBounds(true);
        this.physics.add.collider(gameState.player, gameState.floor);
        this.physics.add.collider(gameState.player, gameState.platforms);
        this.physics.add.collider(gameState.door, gameState.floor);
        this.physics.add.collider(gameState.ladder, gameState.floor);
        this.physics.add.collider(gameState.player, gameState.key, () => {
            gameState.key.destroy();
            gameState.door.anims.play('open', true);
            gameState.doorOpen = true;
        });
    }
}



























