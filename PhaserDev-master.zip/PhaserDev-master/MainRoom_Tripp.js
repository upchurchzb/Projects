class MainRoom_Tripp extends Level {
    constructor() {
        super("MainRoom_Tripp");
    }

    preload() {
        //door, player, key
        super.loadAssets();   
        //this.load.spritesheet('hero', 'assets/adventurerSheet.png', {frameWidth: 50, frameHeight: 37});
        
        this.load.image('bg', './assets/background.png');
        this.load.image('ladd', './assets/ladder2.png');
        this.load.spritesheet('dino', './assets/Dino.png', {frameWidth: 24, frameHeight: 24});
        this.load.spritesheet('firetrap', './assets/Traps/Fire_Trap.png', {frameWidth: 32, frameHeight: 41});
        this.load.image('floor', './assets/background.png');
        //this.load.spritesheet('door', 'assets/Door_Open_v2.png', {frameWidth: 18, frameHeight: 32});
        //this.load.image('key', 'assets/key.png');
        //console.log(" window width: " + window.innerWidth  + " window height: " + window.innerHeight  + " pixelRatio: " + window.devicePixelRatio);
         
    }

    create() {
        //Turn it on and add the player

        gameState.active = true;
        super.createPlayer(250,475);
        this.createRoom();
        super.createKeyDoor(425,window.innerHeight-64,100,window.innerHeight-64);
        this.createTraps(); 
        this.createDino(); 
        super.setColliders();
  
        gameState.player.isTouchingEnemy = false;

        
        //create ground and add physics to player. This assumes 900 width
        const ground0 = this.physics.add.staticGroup();
        ground0.create(225, 800, 'bg');
        this.physics.add.collider(gameState.player, ground0);
        const ground1 = this.physics.add.staticGroup();
        ground1.create(675, 800, 'bg');
        this.physics.add.collider(gameState.player, ground1)
        var platforms = [ground0, ground1];
        for (let i = 0; i < platforms.length; i++){
            this.physics.add.collider(gameState.player, platforms[i]);
        }

        this.createDoor(platforms);
        this.dinoCreate(platforms);
      
        //create ladders and add physics
        const ladder0 = this.physics.add.sprite(350, 475, 'ladd');
        var ladders = [ladder0];
        gameState.ladders = ladders;
        for (let i = 0; i < ladders.length; i++){
            for (let j = 0; j < platforms.length; j++){
                this.physics.add.collider(ladders[i], platforms[j]);
            }
        }
        gameState.player.setCollideWorldBounds(true);
        
        //create cursors
        gameState.cursors = this.input.keyboard.createCursorKeys();
        
        //create hero anims 
        this.anims.create({
            key: 'run',
            frames: this.anims.generateFrameNumbers('hero', {start: 8, end: 13, first: 8}),
            frameRate: 5,
            repeat: -1
        });
        this.anims.create({
            key: 'idle',
            frames: this.anims.generateFrameNumbers('hero', {start: 0, end: 3, first: 0}),
            frameRate: 5,
            repeat: -1
        });
        this.anims.create({
            key: 'jump',
            frames: this.anims.generateFrameNumbers('hero', {start: 13, end: 16, first: 13}),
            frameRate: 5,
            repeat: -1         
        }); 
        this.anims.create({
            key: 'crouch',
            frames: this.anims.generateFrameNumbers('hero', {start: 4, end: 7}),
            frameRate: 5,
            repeat: -1
        });
        this.anims.create({
            key: 'climb',
            frames: this.anims.generateFrameNumbers('hero', {start: 87, end: 90}),
            frameRate: 5,
            repeat: -1
        });

	super.displayLives();	      

    }

    update() {
        if (gameState.active) {
            super.playerMove();
            this.dinoUpdate();


	    super.updateLives();


            this.trapsUpdate();
            //this.updateDoor();
            super.sceneChange(MainRoom_Tripp);
            if (gameState.player.isTouchingEnemy){
                this.scene.restart();
            }
        }
    }

    createRoom(){ 
        //create ground and add physics. This assumes 900 width
        gameState.floor = this.physics.add.staticGroup();
        //gameState.floor.create(window.innerWidth/2,window.innerHeight,'bg');
        //Not sure how to tell the height/width of an asset like the ladder to 
        //correcty offset.. for now it has to be manually completed.
        var block = this.add.tileSprite(0,window.innerHeight,window.innerWidth*2, 32*2, 'bg');
        gameState.floor.add(block,true);
        gameState.platforms = this.physics.add.staticGroup();
        this.physics.add.collider(gameState.player, gameState.platforms);
        //create ladders and add physics
        gameState.ladders = this.physics.add.staticGroup();
        gameState.ladders.create(350,window.innerHeight-90,'ladd');
        this.physics.add.collider(gameState.ladders, gameState.platforms);
        this.physics.add.overlap(gameState.player, gameState.ladders, function () {
            if (gameState.cursors.up.isDown) {
                gameState.player.setVelocity(-125);
            }
        });
    }

    createDino(){
        //dino sprite
        gameState.dino = this.physics.add.sprite(100, window.innerHeight-64, 'dino');
        //set colliders
        gameState.dino.setCollideWorldBounds(true);
        this.physics.add.collider(gameState.dino, gameState.platforms);
        this.physics.add.collider(gameState.dino, gameState.floor);
        //first number is width, second is height of body, true to center on sprite
        gameState.player.body.setSize(10,35, true);
        gameState.player.body.debugShowBody = true;
        gameState.dino.body.setSize(7,10, true);
        gameState.dino.body.debugShowBody = true;
        this.physics.add.collider(gameState.dino, gameState.player, function (){
            gameState.player.isTouchingEnemy = true;
        });
        
        this.anims.create({
            key: 'walk',
            frames: this.anims.generateFrameNumbers('dino', {start: 4, end: 8}),
            frameRate: 5,
            repeat: -1 
        });
        gameState.dino.setVelocityX(50);
        gameState.dino.anims.play('walk', true);
    }

    dinoUpdate(){
        //body.blocked.right/left are true when hitting world bounds
        if (gameState.dino.body.blocked.right){ //onWall()
            gameState.dino.setVelocityX(-50);
            gameState.dino.flipX = true;
        }
        else if (gameState.dino.body.blocked.left){
            gameState.dino.setVelocityX(50);
            gameState.dino.flipX = false;
        }
        //body.touching interacts with the other objects: ie player, background
        else if (gameState.dino.body.touching.left) {
            gameState.dino.setVelocityX(50);
            gameState.dino.flipX = false           
        }
        else if (gameState.dino.body.touching.right) {
            gameState.dino.setVelocityX(-50);
            gameState.dino.flipX = true;
        }
        else {
            gameState.dino.anims.play('walk', true);
        }
    }

    createTraps(platforms) {
        gameState.trap = this.physics.add.sprite(300, window.innerHeight-64, 'firetrap');
        gameState.trap.body.allowGravity = false;
        //Animations
        this.anims.create({
            key: 'fire',
            frames: this.anims.generateFrameNumbers('firetrap', {start: 1, end: 14}),
            frameRate: 5,
            repeat: -1
        });

        gameState.trap.anims.play('fire', true); 
    }

    trapsUpdate(){

        //overlap(obj1, obj2, collideCallback, processCallback, callbackContext)
        this.physics.add.overlap(gameState.player, gameState.trap,
            function() {
            //console.log(gameState.trap.anims.currentFrame);
                gameState.player.isTouchingEnemy = true;
            },
            function() {
                return gameState.trap.anims.currentFrame.textureFrame == 9;
            })
    } 
}
