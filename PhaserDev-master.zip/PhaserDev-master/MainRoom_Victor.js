class MainRoom_Victor extends Level {
    constructor() {
        super('MainRoom_Victor');
    }
    
    preload() {
        super.loadAssets();
        this.load.spritesheet('blue_red', 'assets/Blue_To_Red.png', {frameWidth: 32, frameHeight: 20});
        this.load.spritesheet('blue_red', 'assets/Purple_To_Yellow.png', {frameWidth: 32, frameHeight: 20});
        this.load.spritesheet('blocks', 'assets/Color_Blocks.png', {frameWidth: 16, frameHeight: 16});
        this.load.image('moss_', 'assets/floatingIsland2.png');
        this.load.image('bg', 'assets/background.png');
        this.load.image('ladd', 'assets/ladder2.png');
    }
    
    create() {
        gameState.active = true;   
        super.createPlayer(250, 350); 
        super.createKeyDoor(250, 200, 450, 376);
        gameState.floor = this.physics.add.staticGroup();
        gameState.floor.create(250, 650, 'bg');
        super.setColliders();
                
        var moss = this.physics.add.image(270, 305, 'moss_').setScale(.25).setImmovable(true);
        moss.body.setAllowGravity(false);
        
        /**
         * Colliders
         */
        this.physics.add.collider(gameState.player, moss);
        
        /**
         * Animations
         */
        //Lever Animations
        this.anims.create({
            key: 'switchToRed',
            frames: this.anims.generateFrameNumbers('blue_red', {start: 0, end: 3}),
            frameRate: 10,
            repeat: 0
        });
        this.anims.create({
            key: 'switchToBlue',
            frames: this.anims.generateFrameNumbers('blue_red', {start: 3, end: 0}),
            frameRate: 10,
            repeat: 0
        });
        
        //Red block becomes transparent        
        this.anims.create({
            key: 'redClear',
            frames: this.anims.generateFrameNumbers('blocks', {start: 1, end: 0}),
            frameRate: 5,
            repeat: 0
        });
        //Red block becomes solid        
        this.anims.create({
            key: 'redSolid',
            frames: this.anims.generateFrameNumbers('blocks', {start: 0, end: 1}),
            frameRate: 5,
            repeat: 0
        });
        
        this.createLadders();
        this.createLevers();
        this.createBlocks();
         
    }//end of create
    
    createLadders() {
        gameState.ladderGroup = this.physics.add.group();
        gameState.ladderGroup.create(350, 335, 'ladd');
        this.physics.add.collider(gameState.ladderGroup, gameState.floor);
    }

    createLevers() {
        gameState.leverGroup = this.physics.add.group();
        gameState.leverGroup.create(25, 375, 'blue_red');
        gameState.leverGroup.create(100, 375, 'blue_red');
        this.physics.add.collider(gameState.leverGroup, gameState.floor);
        gameState.leverBlueArr = [true, true];
    }

    createBlocks() {
        gameState.block1 = this.physics.add.staticGroup();
        gameState.block1.create(350, 245, 'blocks', 1).setScale(1.5);
        gameState.block2 = this.physics.add.staticGroup();
        gameState.block2.create(200, 245, 'blocks', 1).setScale(1.5);
        gameState.blockArr = [gameState.block1, gameState.block2];
        gameState.blockColArr = [gameState.blockArr.length];
        for (var i = 0; i < gameState.blockArr.length; i++) 
            gameState.blockColArr[i] = this.physics.add.collider(gameState.player, gameState.blockArr[i]);
    }

    update() {
        if (gameState.active) {
            //super.playerMove();
            
            //updated player movements    
            if (gameState.cursors.left.isDown) {
                gameState.player.setVelocityX(-200);
                gameState.player.anims.play('run', true);
                gameState.player.flipX = true;
            } else if (gameState.cursors.right.isDown) {
                gameState.player.setVelocityX(200);
                gameState.player.anims.play('run', true);
                gameState.player.flipX = false;
            } else if (gameState.cursors.up.isDown) {
                var a = gameState.player.getBounds();
                gameState.ladderGroup.children.iterate(function(child) {
                    var b = child.getBounds();
                    if (Phaser.Geom.Intersects.RectangleToRectangle(a, b)) {
                        gameState.player.setVelocityY(-100);
                        gameState.player.anims.play('climb', true);
                    }
                });
            } else if (gameState.cursors.space.isDown && gameState.player.body.touching.down) {
                gameState.player.setVelocityY(-200);
                gameState.player.anims.play('jump', true);
            } else {
                gameState.player.setVelocityX(0);
                gameState.player.anims.play('idle', true);
            }
            
            //player/lever/block logic 
            if (Phaser.Input.Keyboard.JustDown(gameState.cursors.down)) {
                var a = gameState.player.getBounds();
                var levIndex = 0;
                gameState.leverGroup.children.iterate(function(child) {
                    var b = child.getBounds();
                    /*
                     *  In order: play lever animation, change lever color status, change collider status, play block animation
                    */
                    if (Phaser.Geom.Intersects.RectangleToRectangle(a, b) && gameState.leverBlueArr[levIndex] ){
                        child.anims.play('switchToRed', true);
                        gameState.leverBlueArr[levIndex] = false;
                        gameState.blockColArr[levIndex].active = false;
                        gameState.blockArr[levIndex].playAnimation('redClear', true);
                    } else if (Phaser.Geom.Intersects.RectangleToRectangle(a, b) && !gameState.leverBlueArr[levIndex] ){
                        child.anims.play('switchToBlue', true);
                        gameState.leverBlueArr[levIndex] = true;
                        gameState.blockColArr[levIndex].active = true;
                        gameState.blockArr[levIndex].playAnimation('redSolid', true);
                    }
                    levIndex++;
                });//leverGroup iterate
            }//end of if (JustDown)
            
            super.sceneChange('MainRoom_Victor');
        
        }//end of if (gameState.active)
    }//end of update
}//end of class
