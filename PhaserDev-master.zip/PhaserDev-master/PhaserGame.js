class roomK extends Phaser.Scene {

    constructor() {
	
    }
}

const gameState = {};

let config = {
    type: Phaser.CANVAS,
    width: 1000,
    height: 800,
    physics: {
	default: 'arcade',
	arcade: {
	    gravity: {y: 200},
	    enableBody: true,
	}
    },
    scene: {
	preload: preload,
	create: create,
	update: update
    }
};

let game = new Phaser.Game(config);

function preload()
{
    this.load.image('ninja', 'assets/TinyNin_1.0/Spritesheets/Red_Spritesheet.png');
    this.load.image('jungle', 'assets/PNG/Background layers/Background.png');
    this.load.image('platform', 'assets/PNG/Background Layers/Layer_0001_8.png'); 
}

function create() 
{
    gameState.jungle = this.add.image(1000, 800, 'jungle');
    gameState.ninja = this.physics.add.sprite(400, 100, 'ninja');
    gameState.cursors = this.input.keyboard.createCursorKeys();
    const platform = this.physics.add.staticGroup();
    platform.create(500, 400, 'platform');
    gameState.ninja.setCollideWorldBounds(true);
    this.physics.add.collider(gameState.ninja, platform);
}

function update()
{
    if (gameState.cursors.right.isDown)
    {
	gameState.ninja.setVelocityX(160);
    }
    else if (gameState.cursors.left.isDown)
    {
	gameState.ninja.setVelocityX(-160);
    }
    else if (gameState.cursors.down.isDown)
    {
	
    }
    else if (gameState.cursors.up.isDown)
    {
	
    }
    else
    {
	gameState.ninja.setVelocity(0);
    }
}
