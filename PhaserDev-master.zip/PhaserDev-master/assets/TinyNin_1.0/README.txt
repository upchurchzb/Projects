Thanks for downloading Tiny Nin Character Pack 1.0!

This asset pack is free for use in personal & commercial applications.

You can find more of my content (Games & Assets) at:

https://churrogelato.itch.io/