const gameState = { 
    speed: 240, 
    ups: 380
};

const config = {
    type: Phaser.AUTO,
    //width: 900,
    //height: 600,
    width: window.innerWidth /** window.devicePixelRatio*/,
    height: window.innerHeight /** window.devicePixelRatio*/, 
    fps: {target: 60},
    backgroundColor: "f0f2fa",
    physics: {
        default: 'arcade',
        arcade: {
            gravity: {y: 600},
            enableBody: true
            //debug: true
        }
    },

    scene: [Tripp2, MainRoom_Kayla, vNewLevel, Upchurch2]
    //scene: [MainRoom_Kayla]
    //MainRoom1, MainRoom_Tripp, MainRoom_Kayla, MainRoom, room1
};
gameState.lives = 3;
const game = new Phaser.Game(config);

