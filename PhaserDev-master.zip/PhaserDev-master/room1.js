class room1 extends Level {
    constructor() {
        super('room1');
    }

    preload() {
        super.loadAssets();
    }

    create() {
        gameState.active = true;

        super.createPlayer(50, window.innerHeight - 50);
        super.createBaseRoom();
        super.createKeyDoor(550, window.innerHeight - 250, window.innerWidth - 75, window.innerHeight - 60);
        super.setColliders();
        this.createPlatforms();
    }

    update() {
        if (gameState.active) {
            super.playerMove();
            super.sceneChange("Upchurch2");
        }
    }

    createPlatforms() {
        gameState.platforms = this.physics.add.staticGroup();
        //gameState.platforms.create(200, 450, 'floor').setScale(0.15, 0.35).refreshBody();
        gameState.platforms.create(200, window.innerHeight - 100, 'grass_terrain');
        gameState.platforms.create(375, window.innerHeight - 150, 'grass_terrain');
        gameState.platforms.create(550, window.innerHeight - 200, 'grass_terrain');
        this.physics.add.collider(gameState.player, gameState.platforms); 
    }
}
