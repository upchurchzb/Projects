class temp  extends Phaser.Scene {
    
    constructor() {
        super("temp");
    }
    preload() {
        this.load.spritesheet('hero', 'assets/adventurerSheet.png', {frameWidth: 50, frameHeight: 37});
        this.load.image('bg', 'assets/background.png');
        this.load.image('ladd', 'assets/ladder1.png'); //new
	this.load.image('platform', 'assets/platform.png');
	this.load.image('help', 'assets/helpButton.png');
	this.load.spritesheet('door', 'assets/Door_Open.png', {frameWidth: 18, frameHeight: 32});
	this.load.image('key', 'assets/key.png');
    }
    create() {
        gameState.active = true;    
        gameState.player = this.physics.add.sprite(250, 350, 'hero').setScale(1.5);
	gameState.player.body.setSize(10,35,true);     
	//gameState.button = this.physics.add.sprite(20, 20, 'help');
	const background = this.physics.add.staticGroup();
        background.create(250, 650, 'bg');
        //const ladder = this.physics.add.staticGroup();
                //ladder.create(350, 335, 'ladd');
                        gameState.ladder = this.physics.add.sprite(384, 255, 'ladd').setScale(.8);
                        	gameState.ladder2 = this.physics.add.sprite(55, 150, 'ladd').setScale(.8);
                        	        gameState.player.setCollideWorldBounds(true);
                        	                this.physics.add.collider(gameState.player, background);
                        	                        this.physics.add.collider(gameState.ladder, background);
                        	                        	this.physics.add.collider(gameState.ladder2, background);
	gameState.key = this.physics.add.image(360, 150, 'key').setScale(.5).setImmovable(true);
	gameState.key.body.setAllowGravity(false);
gameState.door = this.physics.add.sprite(440, 200, 'door').setScale(1.5).setDepth(-10);
	gameState.doorOpen = false;
gameState.cursors = this.input.keyboard.createCursorKeys();

this.anims.create({
            key: 'run',
            frames: this.anims.generateFrameNumbers('hero', {start: 8, end: 13, first: 8}),
            frameRate: 5,
            repeat: -1
        });
this.anims.create({
            key: 'idle',
            frames: this.anims.generateFrameNumbers('hero', {start: 0, end: 3, first: 0}),
            frameRate: 5,
            repeat: -1
        });
this.anims.create({
            key: 'jump',
            frames: this.anims.generateFrameNumbers('hero', {start: 13, end: 16, first: 13}),
            frameRate: 5,
            repeat: -1         
        }); 
this.anims.create({
            key: 'crouch',
            frames: this.anims.generateFrameNumbers('hero', {start: 4, end: 7}),
            frameRate: 5,
            repeat: -1
        });
this.anims.create({
            key: 'climb',
            frames: this.anims.generateFrameNumbers('hero', {start: 81, end: 84}),
            frameRate: 5,
            repeat: -1
        });
	const platforms = this.physics.add.staticGroup();
	platforms.create(80, 305, 'platform').setScale(.4, .3).refreshBody();
	platforms.create(300, 305, 'platform').setScale(.4, .3).refreshBody();
	platforms.create(140, 200, 'platform').setScale(.4, .3).refreshBody();
	platforms.create(360, 200, 'platform').setScale(.4, .3).refreshBody();
	this.physics.add.collider(gameState.player, platforms);
	this.physics.add.collider(gameState.ladder2, platforms);
	gameState.helpButton = this.add.image(30, 30, 'help');	
	gameState.helpButton.setInteractive();
	gameState.move = this.add.text(75, 10, 'Move: arrow keys', {color: "#000000"});
	gameState.jump = this.add.text(75, 25, 'Jump: space bar', {color: "#000000"});
	gameState.crouch = this.add.text(75, 40, 'Crouch: shift', {color: "#000000"});
	gameState.climb = this.add.text(75, 55, 'Climb: up arrow', {color: "#000000"});
	gameState.move.visible = false;
	gameState.jump.visible = false;
	gameState.crouch.visible = false;
	gameState.climb.visible = false;

	this.anims.create({
    	    key: 'open',
    	    frames: this.anims.generateFrameNumbers('door', {start: 0, end: 4}),
    	    frameRate: 5,
    	    repeat: 0
	});

	this.physics.add.collider(gameState.door, background);
	this.physics.add.collider(gameState.player, gameState.key, () => {
    	    gameState.key.destroy();
    	    gameState.door.anims.play('open', true);
    	    gameState.doorOpen = true;
	});	
    }

    update() {	
	gameState.helpButton.on('pointerover', () => {
	    gameState.move.visible = true;
	    gameState.jump.visible = true;
	    gameState.crouch.visible = true;
	    gameState.climb.visible = true;	
	});
	gameState.helpButton.on('pointerout', () => {
	    gameState.move.visible = false;
	    gameState.jump.visible = false;
	    gameState.crouch.visible = false;
	    gameState.climb.visible = false;
	})
if (gameState.active) {
            if (gameState.cursors.left.isDown) {
                if (gameState.cursors.shift.isDown) {
                    gameState.player.setVelocityX(-75);
                    gameState.player.anims.play('crouch', true);
                } else {
                    gameState.player.setVelocityX(-200);
                    gameState.player.anims.play('run', true);
                }
                gameState.player.flipX = true;
            } else if (gameState.cursors.right.isDown) {
                if (gameState.cursors.shift.isDown) {
                    gameState.player.setVelocityX(75);
                    gameState.player.anims.play('crouch', true);
                } else {
                    gameState.player.setVelocityX(200);
                    gameState.player.anims.play('run', true);
                }
                gameState.player.flipX = false;
            } else {
                gameState.player.setVelocityX(0);
                if (gameState.cursors.shift.isDown)
                    gameState.player.anims.play('crouch', true);
                else    
                    gameState.player.anims.play('idle', true);
            }
            if (gameState.cursors.space.isDown && gameState.player.body.touching.down) {
                gameState.player.setVelocityY(-200);
                gameState.player.anims.play('jump', true);
            }
            this.physics.add.overlap(gameState.player, gameState.ladder, 
function() {
                if (gameState.cursors.up.isDown) {
                    gameState.player.setVelocityY(-125);
                    gameState.player.anims.play('climb', true);
                } } )
	    this.physics.add.overlap(gameState.player, gameState.ladder2, 
function() {
		if (gameState.cursors.up.isDown) {
		    gameState.player.setVelocityY(-125);
		    gameState.player.anims.play('climb', true);
		} } )
		
		this.physics.add.overlap(gameState.player, gameState.door, 
function() {
    		if (gameState.doorOpen) {
        	    this.cameras.main.fade(800, 0, 0, 0, false, function(camera, progress) {
            	    this.scene.stop("temp");
            	    this.scene.start("MainRoom");
        	});
    	}
	}, null, this);
        }
    }
}







