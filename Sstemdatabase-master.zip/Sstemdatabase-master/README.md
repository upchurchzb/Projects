# Sstemdatabase

>back button
>General search and advanced search
>Percentage based scalings
>No ID required for insert
>Enhanced Search Function
>Sort is clickable 
>Sort is enhanced
>Seinfeld easter egg > button
