<html>
<body>

<?php 
        include("connection.php");
      
    $Title = $_GET["Title"];
    $Length = $_GET["Length"];
    $Genre = $_GET["Genre"];
    $BPM = $_GET["BPM"];
    $Release_Date = $_GET["Release_Date"];
    $Artist = $_GET["Artist"];
    $Album = $_GET["Album"];
    $sql = "INSERT INTO SONG values ('".$BPM."','".$Genre."','".$Length." ','".$Release_Date."' , ' ".$Title." ' , ' ".$Artist." ' , ' ".$Album."' )";

    if ($mysqli_conn->query($sql) === TRUE) {
            echo "New record created successfully";
    } else if ($Genre || $BPM || $Length ||$Release_Date || $Title || $Artist || $Album) {
        echo "Error: " . $sql . "<br>" . $mysqli_conn->error;
    }
    
    $mysqli_conn->close();
?> 

<br>
Sort by: <a href="sort.php?sort=student_name">Names</a> OR <a href="sort.php?sort=grade">Genre</a>  OR <a href="sort.php?sort=grade">Length</a>  OR <a href="sort.php?sort=grade">Release Date</a> OR <a href="sort.php?sort=grade">Title</a> OR <a href="sort.php?sort=grade">Artist</a> OR <a href="sort.php?sort=grade">Album</a>

</body>
</html>

