<?php
$servername = "localhost";
$username = "basilicedj";
$password = "900619687";
$dbname = "SStemBPM";

// Create connection
$mysqli_conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($mysqli_conn->connect_error) {
    die("Connection failed: " . $mysqli_conn->connect_error);
} 
