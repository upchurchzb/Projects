<!DOCTYPE html>
<html>
<head>
<title>Database</title>
</head>
<body>
<table>
    <th>BPM<th>
    <th>Title</th>
    <th>Genre </th>
    <th>Length</th>
    <th>ReleaseDate</th>
    <th>Artist</th>
    <th>Album</th> 
    <th>ID</th>
    <?php
    
    $conn =  new mysqli(localhost, basilicedj,900619697,SStemBPM);
    if($conn -> connect_error) {
        die("Connection failed:". $conn -> connect_error);
    }

    $sql = "SELECT BPM, Title, Genre, Length, Release_Date, Artist, Album, ID from SONG";
    $result = $conn-> query($sql);

    if($result-> num_rows > 0){
    while($row = $result -> fetch_assoc()) {
        echo "<tr><td>". $row["BPM"] ."</td><td>". $row["Title"] . "</td><td>" . $row["Genre"] . "</td><td>" . $row["Length"] . "</td><td>" . $row["Release_Date"] . "</td><td>" . $row["Artist"] . "</td><td>" . $row["Album"] . "</td><td>" . $row["ID"] . "</td></tr>"

    }
    echo "</table>";
    }
    else {
        echo "0 result";
    }
    $conn-> close()
    ?>
</table>
</body>
</html>
