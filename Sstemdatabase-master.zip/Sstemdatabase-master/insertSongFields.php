<html>
<style>
body,html{
    height:100%;
    margin: 0;
}
.bg {
    /* The image used */
    background-image: url("whitespace2.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
</style>
<body>

<?php

    
    include("connection.php");

    $BPM = $_GET["BPM"];
    $Genre =  $_GET["Genre"];
    $Length = $_GET["Length"];
    $Release_Date = $_GET["Release_Date"];
    $Title = $_GET["Title"];
    $Artist = $_GET["Artist"];
    $Album = $_GET["Album"];
    $ID = $_GET["ID"];

    $sql = "INSERT INTO SONG values ('".$BPM."','".$Genre."','".$Length."','".$Release_Date."','".$Title."','".$Artist."','".$Album."','".$ID."')";
    

    if ($mysqli_conn->query($sql) === TRUE) {
            echo "New record created successfully";
    } else if ($BPM || $Genre || $Length || $Release_Date || $Title || $Artist || $Album || $ID) {
        echo "Error: " . $sql . "<br>" . $mysqli_conn->error;
    }

    $mysqli_conn->close();
?>


<br>
Sort by: <a href="sort.php?sort=BPM">BPM</a> OR <a href="sort.php?sort=Genre">Genre</a> OR <a href="sort.php?sort=Length">Length</a> OR <a href="sort.php?sort=Release_Date">Release Date</a> OR <a href="sort.php?sort=Title">Title</a> OR <a href="sort.php?sort=Artist">Artist</a> OR <a href="sort.php?sort=Album">Album</a>

</body>
</html>

