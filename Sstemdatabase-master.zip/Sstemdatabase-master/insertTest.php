<html>
<body>

<?php 
        include("testconnection.php");
      
    $FirstName = $_GET["FirstName"];
    $LastName = $_GET["LastName"];

    $sql = "INSERT INTO testtable values ('".$student_name."','".$grade."')";

    if ($mysqli_conn->query($sql) === TRUE) {
            echo "New record created successfully";
    } else if ($FirstName || $LastName) {
        echo "Error: " . $sql . "<br>" . $mysqli_conn->error;
    }
    
    $mysqli_conn->close();
?> 

<br>
Sort by: <a href="sorttest.php?sort=FirstName">First</a> OR <a href="sorttest.php?sort=LastName">Last</a>

</body>
</html>

