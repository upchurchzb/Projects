<html>
<head>
    <title>Search</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<style> 
h3{color = "white";}
</style>
<body background = "whitespace.jpg">

<form action="search.php" method="GET">
    <input type="text" name="query" />
    <input type="submit" value="Search" />
</form>


<?php
   
    mysql_connect("localhost","basilicedj","900619687","SStemBPM");
    mysql_select_db("SStemBPM") or die(mysql_error());
   $query = $_GET['query'];
    
    $raw_results = mysql_query("SELECT * FROM SONG
            WHERE (`Title` LIKE '%".$query."%') OR (`Artist` LIKE '%".$query."%')") or die(mysql_error());

    if(mysql_num_rows($raw_results) > 0){
    while($results = mysql_fetch_array($raw_results)){
        echo"<p><h3>".$results['Title']."</h3>".$results['Artist']."</p>";
        }
        }
?> 
</body>
</html>
