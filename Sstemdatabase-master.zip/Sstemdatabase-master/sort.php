<html>
<body background = "whitespace3.jpg">

<style>
#music {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#music td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#music tr:nth-child(even){background-color: #5f71b7;}
#music tr:nth-child(odd){background-color: #6483d6;}
#music tr:hover {background-color: #8975c4;}

#music th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #0342a8;
  color: white;
}
</style>
<table id = "music">
    <tr>
        <th>BPM</th>
        <th>Title</th>
        <th>Genre</th>
        <th>Length</th>
        <th>ReleaseDate</th>
        <th>Artist</th>
        <th>Album</th>
    </tr>
<?php 
      	include("connection.php");
      
	$sort = $_GET["sort"];

	$sql = "SELECT * FROM SONG order by ".$sort;
	$result = $mysqli_conn->query($sql);

	if ($result->num_rows > 0) {
	    // output data of each row
	    while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["BPM"]. "</td>";
            echo "<td>" . $row["Title"]. "</td>";
            echo "<td>" . $row["Genre"]. "</td>";
            echo "<td>" . $row["Length"] . "</td>";
            echo "<td>" . $row["Release_Date"] . "</td>";
            echo "<td>" . $row["Artist"] . "</td>"; 
            echo "<td>" . $row["Album"] . "</td>";
            echo"</tr>";
	  }
	}
	
	$mysqli_conn->close();
?> 

Sort by: <a href="sort.php?sort=BPM">BPM </a>   <a href =" sort.php?sort=Title">Title </a>   <a href="sort.php?sort=Genre">Genre </a> <a href="sort.php?sort=Length">Length </a> <a href="sort.php?sort=Release_Date">Release Date </a> <a href= "sort.php?sort=Artist">Artist </a> OR <a href= "sort.php?sort=Album">Album </a>

</body>
</html>
