<html>
<body>

<?php 
        include("connectionSong.php");
      
    $sort = $_GET["sort"];

    $sql = "SELECT * FROM SONG order by ".$sort;
    $result = $mysqli_conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo "BPM: " . $row["BPM"]. " Genre: " . $row["Genre"]. "Length: " .$row["Length"]."Release Data: " .$row["Release_Date"]."Title: " .$row["Title"]. "Artist: " .$row["Artist"]."Album" .$row["Album"]. "<br>";
        }
    }
    
    $mysqli_conn->close();
?> 

Sort by: <a href="sort.php?sort=BPM">BPM</a> OR <a href="sort.php?sort=Genre">Genre</a> OR <a href="sort.php?sort=Length">Length</a> OR <a href="sort.php?sort=Release_Date">Release_Date</a> OR <a href="sort.php?sort=Title">Title</a> OR <a href="sort.php?sort=Artist">Artist</a> OR <a href="sort.php?sort=Album">Album</a>

</body>
</html>

