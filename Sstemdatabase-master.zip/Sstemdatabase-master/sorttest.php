<html>
<body>

<?php 
        include("testconnection.php");
      
    $sort = $_GET["sort"];

    $sql = "SELECT * FROM testtable order by ".$sort;
    $result = $mysqli_conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo "Name: " . $row["FirstName"]. " grade: " . $row["LastName"]."<br>";
        }
    }
    
    $mysqli_conn->close();
?> 

Sort by: <a href="sorttest.php?sort=FirstName">Names</a> OR <a href="sorttest.php?sort=LastName">Grades</a>

</body>
</html>

