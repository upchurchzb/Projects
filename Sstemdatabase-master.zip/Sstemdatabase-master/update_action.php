<html>
<body>

<?php 
      	include("connection.php");
      
	$student_name = $_GET["student_name"];
	$grade = $_GET["grade"];

	$sql = "INSERT INTO Grades values ('".$student_name."',".$grade.")";

	if ($mysqli_conn->query($sql) === TRUE) {
    		echo "New record created successfully";
	} else if ($student_name || $grade) {
	    echo "Error: " . $sql . "<br>" . $mysqli_conn->error;
	}
	
	$mysqli_conn->close();
?> 

<br>
Sort by: <a href="sort.php?sort=student_name">Names</a> OR <a href="sort.php?sort=grade">Grades</a>

</body>
</html>
