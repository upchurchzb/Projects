// Fill out your copyright notice in the Description page of Project Settings.

#include "ActorX.h"

// Sets default values
AActorX::AActorX()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	Mesh = CreateDefaultSubobject<UStaticMeshComponent>("MISH2");
}

// Called when the game starts or when spawned
void AActorX::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AActorX::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	FVector newlocation = GetActorLocation();
	if (newlocation.X > 800.0f)
	{
		bImgoingX = false;
	}
	else if (newlocation.X < 500.0f)
	{
		bImgoingX = true;
	}
	float nond = (bImgoingX ? 100.f : -100.f);
	newlocation.X += nond * DeltaTime;
	SetActorLocation(newlocation);

}

