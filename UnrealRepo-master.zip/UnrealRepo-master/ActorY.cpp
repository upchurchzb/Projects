// Fill out your copyright notice in the Description page of Project Settings.

#include "ActorY.h"

// Sets default values
AActorY::AActorY()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	Mesh = CreateDefaultSubobject<UStaticMeshComponent>("MISH2");
}

// Called when the game starts or when spawned
void AActorY::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AActorY::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	FVector newlocation = GetActorLocation();
	if (newlocation.Y > -700.0f)
	{
		bImgoingY = false;
	}
	else if(newlocation.Y < -1000.0f)
	{
		bImgoingY = true;
	}
	float nond = (bImgoingY ? 100.f : -100.f);
	newlocation.Y += nond * DeltaTime;
	SetActorLocation(newlocation);
}

