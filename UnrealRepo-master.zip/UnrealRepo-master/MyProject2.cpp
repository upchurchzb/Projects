// Fill out your copyright notice in the Description page of Project Settings.

#include "MyProject2.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, MyProject2, "MyProject2" );
