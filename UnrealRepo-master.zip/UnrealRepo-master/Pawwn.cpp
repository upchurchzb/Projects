// Fill out your copyright notice in the Description page of Project Settings.

#include "Pawwn.h"
#include "GameFramework/Pawn.h"
#include "Classes/Components/InputComponent.h"

#include "Classes/GameFramework/FloatingPawnMovement.h"
#include "Classes/GameFramework/SpringArmComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Classes/Camera/CameraComponent.h"

// Sets default values
APawwn::APawwn()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	
	FloatingPawnMovement = CreateDefaultSubobject<UFloatingPawnMovement>("PawnMovement");
	


	CubeMesh = CreateDefaultSubobject<UStaticMeshComponent>("CubeMesh");

	CameraArm = CreateDefaultSubobject<USpringArmComponent>("CameraSpringArm");
	CameraArm->SetupAttachment(CubeMesh);
	CameraArm->TargetArmLength = 500.0f;

	Camera = CreateDefaultSubobject<UCameraComponent>("CameraComponent");
	Camera->SetRelativeLocation(FVector(-500.f, 0.f, 0.f));
	Camera->SetupAttachment(CameraArm);
	SetRootComponent(CubeMesh);
		

	bUseControllerRotationPitch = true;
	bUseControllerRotationYaw = true;
}

// Called when the game starts or when spawned
void APawwn::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void APawwn::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void APawwn::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	PlayerInputComponent->BindAxis("MoveForward", this, &APawwn::MoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &APawwn::MoveRight);
	PlayerInputComponent->BindAxis("Turn", this, &APawwn::Turn);
	PlayerInputComponent->BindAxis("Lookup", this, &APawwn::Lookup);
}

void APawwn::MoveForward(float Value)
{
	FloatingPawnMovement->AddInputVector(GetActorForwardVector() * Value);
}
void APawwn::MoveRight(float Value)
{
	FloatingPawnMovement->AddInputVector(GetActorRightVector() * Value);

}

void APawwn::Turn(float Value)
{
	AddControllerYawInput(Value);
}

void APawwn::Lookup(float Value)
{
	AddControllerPitchInput(Value);
}


