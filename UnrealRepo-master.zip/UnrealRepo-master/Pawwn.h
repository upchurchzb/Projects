// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "Pawwn.generated.h"

UCLASS()
class MYPROJECT2_API APawwn : public APawn
{
	GENERATED_BODY()

public:
	// Sets default values for this pawn's properties
	APawwn();


protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	void MoveForward(float Value);

	void MoveRight(float Value);
	void Turn(float Value);
	void Lookup(float Value);

	class UFloatingPawnMovement * FloatingPawnMovement;

	UPROPERTY(EditAnywhere)
		UStaticMeshComponent * CubeMesh;

	UPROPERTY(EditAnywhere)
		class UCameraComponent* Camera;

	UPROPERTY(EditAnywhere)
		class USpringArmComponent* CameraArm;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

};
